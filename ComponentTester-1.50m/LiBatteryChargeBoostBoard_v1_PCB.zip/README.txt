Ultimate Tester!

This project combines the functionality of measuring important parameters of common electronic components like Resistors, Capacitors, Inductors, Diodes, MOSFETs, Transistors, etc., and providing a Variable DC voltage source of 3-15V with upto 1.5-0.5A of current using a Lithium Polymer Battery or USB power along with an ability to measure DC Voltages upto 21V and DC Currents between +-5A. All this compressed into the form factor of an Arduino Uno!

All the BOM, Eagle Schematics, PCB files and PCB Gerber files are in the zip folder.

Source Code to flash Atmega328p is available in folder Transistortester-Warehouse\ComponentTester-1.50m as well as here: https://github.com/pk17r/Transistortester-Warehouse/tree/prash/ComponentTester-1.50m
Atmega328p hex and eep files are available in the zip folder.

Description documentation and video of the project available at https://pk17r.wordpress.com/

Open Source Hardware License:
CERN-OHL-P-2.0
Software License:
The Component Tester project is licensed under EUPL V.1.2 open source license. I am releasing my modifications/additions to the project under the same license.